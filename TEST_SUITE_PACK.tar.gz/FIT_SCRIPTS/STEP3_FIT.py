S = [1.000e+00, 5.000e-01, 5.000e-01, -2.000e+00, 5.000e-01, 4.000e-01]
visname = 'Discs_Gaussian/Discs_Gaussian.alma.out10.noisy.ms'
modelshape = ['disc','disc','Gaussian']
modvars = ['0.,0.,p[0],p[1],1.,0.','0.,0.,-p[0]*p[2]**2.,p[1]*p[2],1.,0.','0.,p[3],p[4],p[5],1.,0.']
pini = [7.000e-01, 6.500e-01, 4.000e-01, -1.500e+00, 6.000e-01, 5.200e-01]
parbound = [[0.,None],[0.,None],[0.,None],[-15,15],[0.,None],[0.,None]]
import time

tic = time.time()

myfit = uvm.uvmultifit(vis = visname, spw = '0',
               model = modelshape, OneFitPerChannel = False,
               var = modvars,write='residuals',
               p_ini = pini,
               bounds=parbound)
msg = ''

for pi in range(len(pini)):
  msg += '\n Parameter %i: %.4f +/- %.4f | True value %.2f'%(pi,myfit.result['Parameters'][pi],myfit.result['Uncertainties'][pi],S[pi])

tac = time.time()

msg += '\n\n DATA READ AND FIT LASTED %.2f SECONDS.\n'%(tac-tic)

resf = open('test3.dat','w')
print('\n\n\nTEST 3: MULTI-COMPONENT WITH CORRELATED VARIABLES\n',file=resf)
print(msg,file=resf)
resf.close()


