field = ''
msout = 'WideField/WideField.vla.d.noisy.ms'
model = ['delta','delta','delta','delta','delta','delta','delta','delta','delta','delta','delta','delta','delta','delta','delta','delta']
modvars = ['1080.000+p[0], -1080.000+p[1], p[2]','1080.000+p[3], -360.000+p[4], p[5]','1080.000+p[6],  360.000+p[7], p[8]','1080.000+p[9], 1080.000+p[10], p[11]',' 360.000+p[12], -1080.000+p[13], p[14]',' 360.000+p[15], -360.000+p[16], p[17]',' 360.000+p[18],  360.000+p[19], p[20]',' 360.000+p[21], 1080.000+p[22], p[23]','-360.000+p[24], -1080.000+p[25], p[26]','-360.000+p[27], -360.000+p[28], p[29]','-360.000+p[30],  360.000+p[31], p[32]','-360.000+p[33], 1080.000+p[34], p[35]','-1080.000+p[36], -1080.000+p[37], p[38]','-1080.000+p[39], -360.000+p[40], p[41]','-1080.000+p[42],  360.000+p[43], p[44]','-1080.000+p[45], 1080.000+p[46], p[47]']
pini = [0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8,0.0,0.0,0.8]
phref = 'J2000 10h00m00.08s 30d00m02.0s'
S = [0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0,0.0,0.0,1.0]
bounds = [[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None],[-5.,5],[-5.,5.],[0.,None]]
import time

tic = time.time()


myfit = uvm.uvmultifit(vis=msout, model=model, var=modvars, field=field,
          p_ini=pini, NCPU = 4, column='data',write='residuals', 
          OneFitPerChannel=False, phase_center=phref,pbeam=True,
          dish_diameter=25.0, ldfac = 1.0, LMtune=[1.e-3,10.,1.e-5,10],bounds=bounds)

msg = ''


for pi in range(len(pini)//3):
  msg += '\n Flux of delta %i: %.4f +/- %.4f Jy | True value: %.2f Jy'%(pi,myfit.result['Parameters'][3*pi+2],myfit.result['Uncertainties'][3*pi+2],S[3*pi+2])

msg += '\n\n OFFSETS (TAKE INTO ACCOUNT THE COARSE GRIDDING IN SIMOBSERVE!)\n:'
for pi in range(len(pini)//3):
  msg += '\n RA offset delta %i: %.4f +/- %.4f as | True value: %.2f as'%(pi,myfit.result['Parameters'][3*pi],myfit.result['Uncertainties'][3*pi],S[3*pi])

  msg += '\n Dec offset delta %i: %.4f +/- %.4f as | True value: %.2f as'%(pi,myfit.result['Parameters'][3*pi+1],myfit.result['Uncertainties'][3*pi+1],S[3*pi+1])

#msg += '\nGlobal offset RA: %.4f +/- %.4f as | True value: %.2f as'%(myfit.result['Parameters'][-2],myfit.result['Uncertainties'][-2],S[-2])
#msg += '\nGlobal offset Dec: %.4f +/- %.4f as | True value: %.2f as'%(myfit.result['Parameters'][-1],myfit.result['Uncertainties'][-1],S[-1])

tac = time.time()

msg += '\n\n DATA READ AND FIT LASTED %.2f SECONDS.\n'%(tac-tic)

resf = open('test4.dat','w')
print('\n\n\nTEST 4: WIDE FIELD AND MOSAIC.\n',file=resf)
print(msg,file=resf)
resf.close()


