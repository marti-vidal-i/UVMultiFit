S = [2.450e-01, 1.000e+00, 3.000e-01, 5.000e-01, 6.000e+01]
visname = 'Disc/Disc.alma.out10.noisy.ms'
modelshape = 'disc'
modvars = '0,0,p[0]*(nu/5.0000e+10)**p[1],p[2],p[3],p[4]'
pini = [8.000e-01, 0.000e+00, 3.600e-01, 1.250e-01, 4.500e+01]
parbound = [None, None, None, None, None]
import time

tic = time.time()

myfit = uvm.uvmultifit(vis = visname, spw = '0',
               model = modelshape, OneFitPerChannel = False,
               var = modvars,write='residuals',
               p_ini = pini,
               bounds=parbound)

msg = '\nDisc Flux at 50GHz (Jy): %.4f +/- %.4f ; True: %.3f '%(myfit.result['Parameters'][0],myfit.result['Uncertainties'][0],S[0])
msg += '\nDisc Spectral Index:  %.4f +/- %.4f ; True: %.3f '%(myfit.result['Parameters'][1],myfit.result['Uncertainties'][1],S[1])
msg += '\nDisc Size (as):  %.4f +/- %.4f ; True: %.3f '%(myfit.result['Parameters'][2],myfit.result['Uncertainties'][2],S[2])
msg += '\nDisc Axis Ratio:  %.4f +/- %.4f ; True: %.3f '%(myfit.result['Parameters'][3],myfit.result['Uncertainties'][3],S[3])
msg += '\nDisc Pos. Ang (deg.):  %.4f +/- %.4f ; True: %.3f '%(myfit.result['Parameters'][4],myfit.result['Uncertainties'][4],S[4])

tac = time.time()

msg += '\n\n DATA READ AND FIT LASTED %.2f SECONDS.\n'%(tac-tic)

resf = open('test1.dat','w')
print('\n\n\nTEST 1: ELLIPTICITY\n',file=resf)
print(msg,file=resf)
resf.close()


