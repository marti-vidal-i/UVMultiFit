LMtune = [1.e-5,10.,1.e-5,10]
S = [3.500e+00, 1.500e+00, 6.667e-01, 4.500e+01, 1.000e+00, 1.500e+00]
visname = 'Gaussian/Gaussian.pdbi-a.ms.noisy'
amp_gains = {'tG':{'E24':'pieceWise(p[4],p[5],0.00000000e+00,1.79900000e+03)'}}
modelshape = ['Gaussian']
modvars = ['0.,0.,p[0],p[1],p[2],p[3]']
pini = [2.450000e+00, 1.950000e+00, 5.333333e-01, 3.375000e+01, 8.000000e-01, 1.200000e+00]
parbound = [[0.,None],[0.,None],[0.,None],[0.,90.],[0.75,1.25],[1.1,1.9]]
STK = 'RR'
import time

tic = time.time()


myfit = uvm.uvmultifit(vis = visname, spw = '0', stokes = STK,
               model = modelshape, OneFitPerChannel = False,
               var = modvars, write = 'residuals',LMtune=LMtune,
               p_ini = pini, amp_gains = amp_gains,
               bounds=parbound)
msg = ''

for pi in range(len(pini)):
  msg += '\n Parameter %i: %.4f +/- %.4f | True value %.2f'%(pi,myfit.result['Parameters'][pi],myfit.result['Uncertainties'][pi],S[pi])

tac = time.time()

msg += '\n\n DATA READ AND FIT LASTED %.2f SECONDS.\n'%(tac-tic)


resf = open('test5.dat','w')
print('\n\n\nTEST 5: SIMULTANEOUS GAIN CALIBRATION \n(TIME-VARYING AMP. GAIN, USING A PIECE-WISE TIME FUNCTION)\n',file=resf)
print(msg,file=resf)
resf.close()


