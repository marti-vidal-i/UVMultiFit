import os
import tarfile

tf = tarfile.open('TEST_SUITE_PACK.tar.gz', mode='w:gz')

pys = [f[2:-1] for f in os.popen('find ./ -name "*.py" -print')]

pys.append('ALLTESTS.RESULTS')
pys.append('README')

for fi in pys:
  tf.add(fi)

tf.close()
