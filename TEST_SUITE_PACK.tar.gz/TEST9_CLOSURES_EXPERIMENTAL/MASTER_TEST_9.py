import numpy as np
import scipy as sp
import pylab as pl
import os
#from simutil import *


# TEST 9: FITTING TO CLOSURE QUANTITIES 

# What to do:
if False:
  DoSimObs = False # Regenerate the synthetic data
  DoFit = True # Fit them
  casaexe='casa --nologger' # To run CASA in parallel!



# Array to use:
arrayconfig = 'vla.b.cfg'


# Center Freq:
Nu = '15.0GHz'

# Image size (pixels)
Npix = 1000

# Pixel size:
cell = '0.01arcsec' ; cellN = 0.01

# Number of frequency channels:
Nnu = 1

# Channel width:
ChW = '0.5GHz'

# For test 9: DOUBLE (ASSYMMETRIC) SOURCE
imname = 'Double-Source'
     # type   flux    major       minor       PA  freq   spec.ind.    Direction
s=[['disk',   1.0, '0.1arcsec', '0.1arcsec', '0.0deg',Nu, 0.0, "J2000 10h00m00.0s 30d00m00.0s"],
   ['disk',   0.5, '0.1arcsec', '0.1arcsec', '0.0deg',Nu, 0.0, "J2000 10h00m00.0s 30d00m02.5s"]]

config = '.'.join(arrayconfig.split('.')[:-1])


if DoSimObs:


#################################
 print('Generating %s'%imname)

 cl.done()

 for si in s:
    cl.addcomponent(dir=si[7], flux=si[1], fluxunit='Jy', freq=si[5], shape=si[0], 
       majoraxis=si[2], minoraxis=si[3], positionangle=si[4], 
       spectrumtype='spectral index', index=si[6])

 ia.fromshape(imname+'.model',[Npix,Npix,1,Nnu],overwrite=True)
 cs=ia.coordsys()
 cs.setunits(['rad','rad','','Hz'])
 cell_rad=qa.convert(qa.quantity(cell),"rad")['value']
 cs.setincrement([-cell_rad,cell_rad],'direction')
 rdi,ddi = s[0][7].split()[1:]
 cs.setreferencevalue([qa.convert(rdi,'rad')['value'],qa.convert(ddi,'rad')['value']],type="direction")
 cs.setreferencevalue(s[0][5],'spectral')
 cs.setincrement(ChW,'spectral')
 ia.setcoordsys(cs.torecord())
 ia.setbrightnessunit("Jy/pixel")
 ia.modify(cl.torecord(),subtract=False)
 ia.close()

 simobserve(project=imname, skymodel = imname+'.model',
            totaltime = '300s',antennalist=arrayconfig)


##########################
## CORRUPT PHASES AND AMPLITUDES:

 print('CORRUPTING PHASES AND AMPLITUDES')

 visname = '%s/%s.%s.noisy.ms'%(imname,imname,config)

# Number of antennas:
 tb.open('%s/ANTENNA'%visname)
 NANTS = len(tb.getcol('NAME'))

# Random antenna-based phases:
 PHASES = np.random.random(NANTS)*2.*np.pi
 tb.close()

# Random antenna-based amplitudes:
 AMPS = np.ones(NANTS)*0.5 + np.random.random(NANTS)*10.

# FIRST ANTENNA IS NOT AFFECTED BY GAIN AMPLITUDE:
# THIS IS TO TEST THE USE OF "TRISPECTRA": 
 AMPS[0] = 1.0


# Read data:
 tb.open(visname,nomodify=False) 
 ANT1 = tb.getcol('ANTENNA1')
 ANT2 = tb.getcol('ANTENNA2')
 TIMES = tb.getcol('TIME')
 UTs = np.unique(TIMES)
 DATA = tb.getcol('DATA')

# Add random phases:
 for ai in range(NANTS):
   mask1 = ANT1==ai
   mask2 = ANT2==ai
   DATA[:,:,mask1] *= AMPS[ai]*np.exp(1.j*PHASES[ai])
   DATA[:,:,mask2] *= AMPS[ai]*np.exp(-1.j*PHASES[ai])

 tb.putcol('DATA',DATA)
 tb.close()

###########################









if DoFit:


 tempfile = open('STEP9_FIT.py','w')

# Flux of the strongest source. Any value is OK, since
# the closures are insensitive to absolute fluxes:
 FF = 1.

# Model: A centered point plus an offset point:
 D1var = '0.,0.,%.3f'%FF
 D2var = 'p[0],p[1],p[2]'

 shapes = ['delta','delta']
 fluxes = [float(si[1]) for si in s]

# True parameters (RA offset, Dec offset and flux of second delta):
 Pars = [0.0, 2.5, FF/2.] #,fluxes[2],sizes[2]]

# Bias factors to apply:
 BiasFac = [0.7, 1.3, 0.7]

 
 Trues = Pars

 string = 'S = [%.3e, %.3e, %.3e]'%tuple(Pars)
# print >> tempfile,string
 print(string,file=tempfile)

 string = 'visname = \'%s\''%('%s/%s.%s.noisy.ms'%(imname,imname,config))
# print >> tempfile,string
 print(string,file=tempfile)


 string = 'modelshape = [%s]'%(','.join(['\''+shi+'\'' for shi in shapes]))
# print >> tempfile,string
 print(string,file=tempfile)

 string = 'modvars = [\'%s\',\'%s\']'%(D1var,D2var)
# print >> tempfile,string
 print(string,file=tempfile)

 string = 'pini = [%.3e, %.3e, %.3e]'%tuple([Pars[pi]*BiasFac[pi] for pi in range(len(Pars))])
# print >> tempfile,string
 print(string,file=tempfile)



 string = 'parbound = [[-0.1,None],[0.,None],[0.,None]]'
# print >> tempfile,string
 print(string,file=tempfile)


 lines = open('test9.py')
 for l in lines.readlines():
  # print >> tempfile,l[:-1]
   print(l[:-1],file=tempfile)

 lines.close()
 tempfile.close()



 pl.ioff()
 Cfile = 'TEST9.CLEAN'
 Rfile = 'TEST9.RESIDUALS'
 clearcal('%s/%s.%s.noisy.ms'%(imname,imname,config))
 os.system('rm -rf %s.*'%Cfile)
 os.system('rm -rf %s.*'%Rfile)

 tclean('%s/%s.%s.noisy.ms'%(imname,imname,config),
       imagename = Cfile, cell = cell,
       imsize = Npix, niter = 0)

 ia.open('%s.image'%Cfile)
 resdat = ia.getchunk()[:,:,0,0]
 ia.close()
 fig = pl.figure()
 sub = fig.add_subplot(111) 
 IMsize = cellN*Npix/2.
 ims = sub.imshow(np.transpose(resdat),origin='lower',extent=[IMsize,-IMsize,-IMsize,IMsize])
 sub.set_xlabel('RA offset (arcsec)')
 sub.set_ylabel('Dec offset (arcsec)')
 cb = pl.colorbar(ims)
 cb.set_label('Jy/beam')
 pl.savefig('%s.png'%Cfile)

 impeak = np.max(resdat)

 os.system('%s -c STEP9_FIT.py'%casaexe)


 os.system('rm -rf %s.*'%Rfile)
 tclean('%s/%s.%s.noisy.ms'%(imname,imname,config),
       imagename = Rfile, cell = cell,
       imsize = Npix, niter = 0)


 impeak *= 0.01

 ia.open('%s.image'%Rfile)
 resdat = ia.getchunk()[:,:,0,0]
 ia.close()
 fig = pl.figure()
 sub = fig.add_subplot(111) 
 IMsize = cellN*Npix/2.
 ims = sub.imshow(np.transpose(resdat),vmax=impeak,origin='lower',extent=[IMsize,-IMsize,-IMsize,IMsize])
 sub.set_xlabel('RA offset (arcsec)')
 sub.set_ylabel('Dec offset (arcsec)')
 cb = pl.colorbar(ims)
 cb.set_label('Jy/beam')
 pl.savefig('%s.png'%Rfile)

