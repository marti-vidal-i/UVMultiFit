import time

tic = time.time()

# ANTENNAS ARE: 'A00', 'A01', 'A02', 'A03', 'A04', 'A05', 'A06', 'A07', 'A08',
#               'A09', 'A10', 'A11', 'A12', 'A13', 'A14', 'A15', 'A16', 'A17',
#               'A18', 'A19', 'A20', 'A21', 'A22', 'A23', 'A24', 'A25', 'A26']


myfit = uvm.uvmultifit(vis = visname, spw = '0', NCPU = 1,
               model = modelshape, OneFitPerChannel = False,
               var = modvars,write='residuals',
               phase_closure_Wgt = -1., # negative means NOT to use visibilities!
             #  amp_closure_Wgt = -1.,
             #  trispec_refants = ['A00'], # First antenna has good amplitudes.
               p_ini = pini,
               bounds=parbound)
msg = ''

for pi in range(len(pini)):
  msg += '\n Parameter %i: %.4f +/- %.4f | True value %.2f'%(pi,myfit.result['Parameters'][pi],myfit.result['Uncertainties'][pi],S[pi])

tac = time.time()

msg += '\n\n DATA READ AND FIT LASTED %.2f SECONDS.\n'%(tac-tic)

resf = open('test9.dat','w')
print('\n\n\nTEST 9: FIT TO CLOSURE QUANTITIES\n',file=resf)
print(msg,file=resf)
resf.close()


